package com.example.exercise2

import android.content.Intent
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class LoginPage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val loginButton = findViewById<TextView>(R.id.login)

        loginButton.setOnClickListener {
            val uname = findViewById<TextView>(R.id.username)
            val pass = findViewById<TextView>(R.id.password)

            val defUser = "__ishan.zxcvb"
            val defPass = "admin123"

            if (uname.text.toString() == defUser && pass.text.toString() == defPass) {
                val intent = Intent(this, BottomNavigation::class.java)
                intent.putExtra("username", uname.text.toString())
                startActivity(intent)
            }
            else {
                Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show()
            }
        }
    }



}