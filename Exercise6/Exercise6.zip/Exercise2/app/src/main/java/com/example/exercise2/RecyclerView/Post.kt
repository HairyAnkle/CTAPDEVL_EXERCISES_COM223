package com.example.exercise2.RecyclerView

import androidx.annotation.DrawableRes

data class Post(
    val name: String,
    val order: String,
    @DrawableRes val image: Int
)
