package com.example.exercise2.RecyclerView

import com.example.exercise2.R

object PostNila {

    val theirName = mapOf(
        PostId.POST1 to "__ishan.zxcvb",
        PostId.POST2 to "saki_ryoaki",
        PostId.POST3 to "shawarmom",
        PostId.POST4 to "Adlen Richard",
        PostId.POST5 to "Loonie",
        PostId.POST6 to "Zaito",
        PostId.POST7 to "Aklas",
        PostId.POST8 to "Razzie Binx",
        PostId.POST9 to "Burat",
        PostId.POST10 to "Tite"
    )

    val theirOrder = mapOf(
        PostId.POST1 to "Me",
        PostId.POST2 to "Asawa",
        PostId.POST3 to "Tropa",
        PostId.POST4 to "Professor",
        PostId.POST5 to "BEST MC",
        PostId.POST6 to "BEST JOKER",
        PostId.POST7 to "BEST OF BEST JOKER",
        PostId.POST8 to "JUST BINGO PLUS MY LOCATION PLS!",
        PostId.POST9 to "EKALAM",
        PostId.POST10 to "ABAHAM"
    )

    val theirImage = mapOf(
        PostId.POST1 to R.drawable.post1,
        PostId.POST2 to R.drawable.post2,
        PostId.POST3 to R.drawable.post3,
        PostId.POST4 to R.drawable.post4,
        PostId.POST5 to R.drawable.post5,
        PostId.POST6 to R.drawable.post6,
        PostId.POST7 to R.drawable.post7,
        PostId.POST8 to R.drawable.post8,
        PostId.POST9 to R.drawable.post9,
        PostId.POST10 to R.drawable.post10
    )
}