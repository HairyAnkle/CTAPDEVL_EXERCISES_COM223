package com.example.exercise2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.GetCredentialResponse
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.database.database
import kotlinx.coroutines.launch

class LoginPage : AppCompatActivity() {
    private val DATABASE_URL = R.string.Database_URL
    private lateinit var auth: FirebaseAuth
    private lateinit var credentialManager: CredentialManager


    override fun onStart() {
        super.onStart()
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        auth = Firebase.auth
        credentialManager = CredentialManager.create(baseContext)

        signOut()
        val loginButton = findViewById<TextView>(R.id.login)
        val googleauth = findViewById<TextView>(R.id.loginwith)

        // Google Firebase
        val database = Firebase.database(getString(DATABASE_URL))
        val myRef = database.getReference("message")
        myRef.setValue("Hello, World!")

        // Auth Start

        googleauth.setOnClickListener {
            launchCredentialManager()
        }



        loginButton.setOnClickListener {
            val uname = findViewById<TextView>(R.id.username)
            val pass = findViewById<TextView>(R.id.password)

            val defUser = "__ishan.zxcvb"
            val defPass = "admin123"

            if (uname.text.toString() == defUser && pass.text.toString() == defPass) {
                val intent = Intent(this, BottomNavigation::class.java)
                intent.putExtra("username", uname.text.toString())
                startActivity(intent)
            }
            else {
                Toast.makeText(this, "Invalid Credentials", Toast.LENGTH_SHORT).show()
            }

        }
    }

    private fun launchCredentialManager() {
        val googleIdOption = GetGoogleIdOption.Builder()
            .setFilterByAuthorizedAccounts(false)
            .setServerClientId(baseContext.getString(R.string.default_web_client_id))
            .build()

        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()

        lifecycleScope.launch {
            try {
                val result = credentialManager.getCredential(
                    context = baseContext,
                    request = request
                )

                handleSignInResult(result.credential)
            } catch (e: GetCredentialException) {
                Log.e("GoogleSignIn", "Couldn't retrieve user's credentials: ${e.localizedMessage}")
            }
        }
    }


    private fun handleSignInResult(credential: Credential) {
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)

            firebaseAuthWithGoogle(googleIdTokenCredential.idToken)
        } else {
            Log.w("Google Sign In", "Credential is not of type Google ID!")
        }
    }

    private fun firebaseAuthWithGoogle(googleIdToken: String) {
        val credential = GoogleAuthProvider
            .getCredential(googleIdToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {

                    Log.d("Google SignIn", "signInWithCredential_firebase:success")
                    val user =auth.currentUser
                    updateUI(user)
                } else {
                    Log.w("GoogleSignIn", "signInWithCredential_firebase:failure", task.exception)
                    Toast.makeText(this, "Firebase Authentication failed: ${task.exception?.message}", Toast.LENGTH_LONG).show()                }
            }
    }

    private fun signOut() {
        auth.signOut()

        lifecycleScope.launch {
            try {
                val clearRequest = ClearCredentialStateRequest()
                credentialManager.clearCredentialState(clearRequest)
                updateUI(null)
            } catch (e: ClearCredentialException) {
                Log.e("GoogleSignIn", "Couldn't clear credential state: ${e.localizedMessage}")
            }
        }
    }

    private fun updateUI(user: FirebaseUser?) {
        if (user != null) {
            val intent = Intent(this, BottomNavigation::class.java)
            startActivity(intent)
        }
    }


}