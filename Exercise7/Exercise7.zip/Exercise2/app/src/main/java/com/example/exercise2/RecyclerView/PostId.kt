package com.example.exercise2.RecyclerView

enum class PostId {
    POST1, POST2, POST3, POST4, POST5, POST6, POST7, POST8, POST9, POST10
}